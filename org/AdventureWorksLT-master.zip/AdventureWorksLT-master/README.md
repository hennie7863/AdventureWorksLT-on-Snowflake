# AdventureWorksLT
This repository contains my version of the AdventureWorksLT sample database for SQL Server

If you have issues installing these samples, please go directly to the Microsoft site where you can get any version of this database:
https://docs.microsoft.com/en-us/sql/samples/adventureworks-install-configure?view=sql-server-ver15&tabs=ssms
